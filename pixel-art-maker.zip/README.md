# Pixel Art Maker Project

## Instructions

To get started, open `designs.js` and start building out the app's functionality.

